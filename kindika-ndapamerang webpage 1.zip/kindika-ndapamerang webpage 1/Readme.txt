Thanks for downloading this theme!

Theme Name: BizPage
Theme URL: https://bootstrapmade.com/bizpage-bootstrap-business-template/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com